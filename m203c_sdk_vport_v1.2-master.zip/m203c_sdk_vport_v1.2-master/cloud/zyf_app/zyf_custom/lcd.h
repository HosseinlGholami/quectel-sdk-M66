#ifndef __LCD_H__
#define __LCD_H__


#include "ql_gpio.h"
#include "sys.h"


extern u32 SysVol;
extern u8 Signal;

#endif

