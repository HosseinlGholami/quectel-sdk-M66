#include "ql_type.h"
#include "ql_trace.h"
#include "ql_uart.h"
#include "ql_system.h"
#include "ql_stdlib.h"
#include "ql_error.h"
#include "ql_gpio.h"
#include "sys.h"
#include "lcd.h"
#include "tiem.h"
#include "pro.h"


u32 SysVol=0;
u8 Signal=0;


