

#ifndef _ALIOT_CA_H_
#define _ALIOT_CA_H_


const char *aliot_ca_get(void);


#endif /* _ALIOT_CA_H_ */
